#include "stdafx.h";
int main()
{
	sys_init();
	mainMenu();
	return 0;
}