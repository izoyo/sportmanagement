#include "stdafx.h"

SysInfo sys_info;

int sys_init(){
	FILE * fp;
	SysInfo sys;
    if((fp=fopen("data\\sysinfo.txt", "r"))==NULL) {  
		fp=fopen("data\\sysinfo.txt", "w");
		//printf("write:%d\n",fp);
		sys.not=0;sys.eve=0;sys.peo=0;
		fwrite(&sys, sizeof(SysInfo), 1, fp);
		fclose(fopen("data\\perinfo.txt", "w"));
		fclose(fopen("data\\eveinfo.txt", "w"));
		fclose(fopen("data\\notinfo.txt", "w"));
	}else{
		//printf("read:%d\n",fp);
		fread(&sys, sizeof(SysInfo), 1, fp);
	}
	if (fp!=0) fclose(fp);
	sys_info=sys;
	printf("�û�����%d ��Ŀ����%d ֪ͨ����%d\n",sys_info.peo,sys_info.eve,sys_info.not);
	return 0;
}
int sys_inc(int type){//�������� 0 peo 1 eve 2 not
	FILE * fp;
	if((fp=fopen("data\\sysinfo.txt", "w"))==NULL)
		return 0;
	SysInfo sys;
	switch(type){
		case 0:
			sys_info.peo++;
			break;
		case 1:
			sys_info.eve++;
			break;
		case 2:
			sys_info.not++;
			break;
	}
	sys=sys_info;
	fwrite(&sys, sizeof(SysInfo), 1, fp);
	fclose(fp);
	switch(type){
		case 0:
			return sys_info.peo;
		case 1:
			return sys_info.eve;
		case 2:
			return sys_info.not;
	}
	return 0;
}
int sys_dec(int type){//�������� 0 peo 1 eve 2 not
	FILE * fp;
	if((fp=fopen("data\\sysinfo.txt", "w"))==NULL)
		return 0;
	SysInfo sys;
	switch(type){
		case 0:
			sys_info.peo--;
			break;
		case 1:
			sys_info.eve--;
			break;
		case 2:
			sys_info.not--;
			break;
	}
	sys=sys_info;
	fwrite(&sys, sizeof(SysInfo), 1, fp);
	fclose(fp);
	switch(type){
		case 0:
			return sys_info.peo;
		case 1:
			return sys_info.eve;
		case 2:
			return sys_info.not;
	}
	return 0;
}
